package ma.freevpn.app

import android.app.Activity
import android.content.Intent
import android.net.VpnService
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {
    private val vpnPermission = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            ContextCompat.startForegroundService(
                this, Intent(this, FreeVpnService::class.java).setAction(FreeVpnService.ACTION_START)
            )
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                var status by remember { mutableStateOf("غير متصل") }
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    Column(
                        modifier = Modifier.fillMaxSize().padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Text("FREE", style = MaterialTheme.typography.displayLarge)
                        Spacer(Modifier.height(8.dp))
                        Text("اتصال VPN آمن")
                        Spacer(Modifier.height(32.dp))
                        Text(status, style = MaterialTheme.typography.titleLarge)
                        Spacer(Modifier.height(24.dp))
                        Button(
                            onClick = {
                                val prepare = VpnService.prepare(this@MainActivity)
                                if (prepare != null) vpnPermission.launch(prepare)
                                else ContextCompat.startForegroundService(
                                    this@MainActivity,
                                    Intent(this@MainActivity, FreeVpnService::class.java)
                                        .setAction(FreeVpnService.ACTION_START)
                                )
                                status = "تم طلب إذن VPN — نحتاج إعداد خادم الاتصال"
                            },
                            modifier = Modifier.fillMaxWidth().height(56.dp),
                            shape = RoundedCornerShape(16.dp)
                        ) { Text("CONNECT") }
                        Spacer(Modifier.height(12.dp))
                        OutlinedButton(
                            onClick = {
                                startService(
                                    Intent(this@MainActivity, FreeVpnService::class.java)
                                        .setAction(FreeVpnService.ACTION_STOP)
                                )
                                status = "غير متصل"
                            },
                            modifier = Modifier.fillMaxWidth().height(52.dp),
                            shape = RoundedCornerShape(16.dp)
                        ) { Text("DISCONNECT") }
                        Spacer(Modifier.height(28.dp))
                        Text(
                            "نسخة أولية: الواجهة وطلب إذن VPN جاهزان. يلزم إعداد خادم VPN قانوني قبل نقل البيانات.",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            }
        }
    }
}
