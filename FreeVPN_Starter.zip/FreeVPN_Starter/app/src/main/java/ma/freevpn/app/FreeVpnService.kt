package ma.freevpn.app

import android.net.VpnService
import android.content.Intent
import android.os.ParcelFileDescriptor

/**
 * Starter service only. A real VPN tunnel is NOT implemented yet.
 * Connect this service to an authorized VPN protocol/server (for example WireGuard)
 * before claiming that traffic is protected or routed.
 */
class FreeVpnService : VpnService() {
    private var tunnel: ParcelFileDescriptor? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                // TODO: Initialize a real, authenticated VPN tunnel here.
                // Do not create a fake "connected" state without a working tunnel.
            }
            ACTION_STOP -> stopTunnel()
        }
        return START_NOT_STICKY
    }

    private fun stopTunnel() {
        tunnel?.close()
        tunnel = null
        stopSelf()
    }

    override fun onDestroy() {
        stopTunnel()
        super.onDestroy()
    }

    companion object {
        const val ACTION_START = "ma.freevpn.app.START"
        const val ACTION_STOP = "ma.freevpn.app.STOP"
    }
}
